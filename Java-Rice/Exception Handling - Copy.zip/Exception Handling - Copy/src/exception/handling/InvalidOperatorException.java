package exception.handling;

public class InvalidOperatorException extends Exception {
    public InvalidOperatorException(String message) {
        super(message);
    }
}
