
package exception.handling;


public class ExceptionHandling {


    public static void main(String[] args) {
//        bankAccount bank =  new bankAccount();
//        bank.withdraw();

//        userRegistration user = new userRegistration();
//        user.register();

//        basicCalculator calculator = new basicCalculator();
//        calculator.calculate();
    }
    
}
